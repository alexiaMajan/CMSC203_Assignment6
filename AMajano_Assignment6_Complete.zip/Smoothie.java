/*
 * Class: CMSC203 
 * Instructor:Dr. Grinberg
 * Description: (Give a brief description for each Class)
 * Due: 12/3/2023
 * Platform/compiler:
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Alexia Majano
*/


public class Smoothie extends Beverage {

	private boolean proteinAdd;
	private int numOfFruits;
	private double addedProtein = 1.50;
	private double addedFruit = 0.50;
	
	
	public Smoothie(String name,Size size, int numOfFruits, boolean proteinAdd) {
		super(name, Type.SMOOTHIE, size);
		this.numOfFruits = numOfFruits;
        this.proteinAdd = proteinAdd;

		
	}
	
	public int getNumOfFruits()
	{
		return numOfFruits;
	}
	public boolean getAddProtein() {
		
		return proteinAdd;
	}
	public String toString() {
		 return getname() +" "+ getSize() +
	                " " + proteinAdd +
	                " " + numOfFruits +
	                " " + calcPrice();
	      
		
	}
	
	


	@Override
	public double calcPrice() {
		   double price = addSizePrice();
	        if (proteinAdd) {
	            price += addedProtein;
	        }

	        // Additional cost for each fruit
	        price += numOfFruits * addedFruit;

	        return price;
		
	}
	public boolean equals(Object anotherBev) {
		
		Smoothie smoothie = (Smoothie) anotherBev;
		return super.equals(anotherBev) && this.proteinAdd == smoothie.proteinAdd && this.numOfFruits == smoothie.numOfFruits;
	}
	
	
	
	
	
	

}

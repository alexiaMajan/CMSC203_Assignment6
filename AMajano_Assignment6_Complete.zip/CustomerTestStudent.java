/*
 * Class: CMSC203 
 * Instructor:Dr. Grinberg
 * Description: (Give a brief description for each Class)
 * Due: 12/3/2023
 * Platform/compiler:
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Alexia Majano
*/
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CustomerTestStudent {

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testGetName() {
		Customer customer = new Customer("John ", 23);
		assertEquals("John ", customer.getName());
	}
	@Test
	void testSetName() {
		Customer customer = new Customer("John ", 23);
		customer.setName("Anne");
		assertEquals("Anne", customer.getName());
	}
	@Test
	void testGetAge() {
		Customer customer = new Customer("John ", 23);
		assertEquals(23, customer.getAge());
	}
	@Test
	void testSetAge() {
		Customer customer = new Customer("John ", 23);
		customer.setAge(25);
		assertEquals(25, customer.getAge());
	}
	
	@Test
	void testToString() {
		Customer Customer = new Customer("John ", 23);
		assertEquals("John  23", Customer.toString());
	}

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


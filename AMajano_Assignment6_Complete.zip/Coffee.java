/*
 * Class: CMSC203 
 * Instructor:Dr. Grinberg
 * Description: (Give a brief description for each Class)
 * Due: 12/3/2023
 * Platform/compiler:
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Alexia Majano
*/


public class Coffee extends Beverage {
 
	
	public Coffee(String name,Size size,boolean extraShot, boolean extraSyrup) {
		super(name, Type.COFFEE, size);
		this.extraShot = extraShot;
        this.extraSyrup = extraSyrup;
	}
	private boolean extraShot;
	private boolean extraSyrup;
	
	public boolean getExtraShot()
	{
		return extraShot;
	
	}
	public boolean getExtraSyrup() {
		return extraSyrup;
	}
	

	
	@Override
	public double calcPrice() {
		  double price = addSizePrice();

	        if (extraShot) {
	            price += 0.5; 
	        }

	        if (extraSyrup) {
	            price += 0.5; 
	        }

	        return price;
	    }
	public String toString() {
		
		return  
				getname() + " " +
                getSize()+ " "+ extraShot +
                " " + extraSyrup+ " "+calcPrice();
               
	}
	
	public boolean equals(Object anotherBev)
	{
		Coffee coffee = (Coffee) anotherBev;
		return
				super.equals(anotherBev) && this.extraSyrup == coffee.extraSyrup && this.extraShot == coffee.extraShot;
				
	}
	


}

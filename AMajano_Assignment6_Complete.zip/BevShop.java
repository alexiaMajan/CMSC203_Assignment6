
import java.util.ArrayList;
import java.util.Collections;

public class BevShop implements BevShopInterface {
	
	private int numOfAlcohol;
	private int OrderNo1;
	private ArrayList<Order> orderList;
	
	public BevShop() {
	this.orderList = new ArrayList<>();
		 
	}
	public boolean isValidTime(int time) {
		if (time >= MIN_TIME && time <= MAX_TIME) {
			return true; 
		}
		return false;
	}
	
	@Override
	public int getMaxNumOfFruits() {
		return MAX_FRUIT;
	}
	@Override
	public int getMinAgeForAlcohol() {
		return MIN_AGE_FOR_ALCOHOL;
	}
	@Override
	public boolean isMaxFruit(int numOfFruits) {
		if (numOfFruits > MAX_FRUIT) { 
			return true;
		}
		return false;
	}
	@Override
	public int getMaxOrderForAlcohol() {

		return MAX_ORDER_FOR_ALCOHOL;
	}
	@Override
	public boolean isEligibleForMore() {
		if (numOfAlcohol < MAX_ORDER_FOR_ALCOHOL) 
		{ 
			return true;
		}
		return false;
	}
	@Override
	public int getNumOfAlcoholDrink() {

		return numOfAlcohol;
	}
	@Override
	public boolean isValidAge(int age) {
		if (age > MIN_AGE_FOR_ALCOHOL)
		{ 
			return true; 
		}
		return false;
	}
	
	@Override
	public void startNewOrder(int time, Day day, String customerName, int customerAge) {

		Customer customer = new Customer(customerName, customerAge);
																		
		Order order = new Order(time, day, customer); 
		orderList.add(order); 
		OrderNo1 = orderList.indexOf(order);
		numOfAlcohol = 0; 

	}
	@Override
	public void processCoffeeOrder(String bevName, Size size, boolean extraShot, boolean extraSyrup) {
		orderList.get(OrderNo1).addNewBeverage(bevName, size, extraShot, extraSyrup); 
																						
	}
	@Override
	public void processAlcoholOrder(String bevName, Size size)
	{
		orderList.get(OrderNo1).addNewBeverage(bevName, size);
		numOfAlcohol++;
	}
	@Override
	public void processSmoothieOrder(String bevName, Size size, int numOfFruits, boolean addProtein) {
		orderList.get(OrderNo1).addNewBeverage(bevName, size, numOfFruits, addProtein);
																								
	}
	@Override
	public int findOrder(int orderNo) {
		for (int i = 0; i < orderList.size(); i++) {
			if (orderList.get(i).getOrderNo() == orderNo) {
				return i;
			}
		}
		return -1; 
	}
	@Override
	public double totalOrderPrice(int orderNo)
	{
		double total = 0;
		for(Order order: orderList)
		{
			if(order.getOrderNo() == orderNo)
				total = order.calcOrderTotal();
		}
		return total;
	}
	@Override
	public double totalMonthlySale()
	{
		double totalMonth = 0;
		for (Order orders : orderList) 
		{ 
			for (Beverage bevs : orders.getBeverages()) {
				totalMonth += bevs.calcPrice(); 
			}
		}
		return totalMonth; 
	}
	
	@Override
	public int totalNumOfMonthlyOrders()
	{
		 return orderList.size();
	}
	
	@Override
	public Order getCurrentOrder()
	{
		return orderList.get(OrderNo1);
    }
	@Override
	public Order getOrderAtIndex(int index) {

		return orderList.get(index);
	}
	@Override
	public void sortOrders() {
		for (int i = 0; i < orderList.size() - 1; i++) {
			int change = i;
			for (int j = i + 1; j < orderList.size(); j++) {
				if (getOrderAtIndex(j).getOrderNo() < getOrderAtIndex(change).getOrderNo()) { 
					change = j;
				}
			}
			if (change != i) { 
				Collections.swap(orderList, i, change); 
			}
		}
	}

	
	
	public String toString()
	{
		return orderList.toString() + " \n Total Sale: " + totalMonthlySale();
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
